/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   booklib.h
 * Author: LAPTOP
 *
 * Created on 4 de dezembro de 2020, 13:16
 */

#ifndef BOOKLIB_H
#define BOOKLIB_H
//Constantes
#define MAX_LIVROS 50
#define MAX_CHAR_AUTORES 75
#define MAX_AUTORES 5
#define DIG_ISBN 13
#define MAX_CHAR_TITULO 250
#define MAX_CHAR_EDITORA 50
#define MAX_CHAR_MORADA_EDITORA 250

typedef struct {
    int dia, mes, ano;
} data;

typedef enum {
    FICCAO, TECNICO, ROMANCE, ESTUDO
} tipo_genero;

typedef struct {
    char autores[MAX_CHAR_AUTORES];
} tipo_autores;

typedef struct {
    char morada[MAX_CHAR_MORADA_EDITORA];
    char nome[MAX_CHAR_EDITORA];

} tipo_editora;

typedef struct {
    char ISBN[DIG_ISBN];
    data data_de_publicacao;
    char titulo[MAX_CHAR_TITULO];
    tipo_genero tipo;
    tipo_editora editora;
    tipo_autores autores[MAX_AUTORES];

} tipo_livro;

int aux;

int inserir_livro(int *count, tipo_livro livro[]) {
    int a = *count;
    int aux = 0;

    printf("\n\nMENU: INSERIR LIVRO");


    printf("\n\nLIVRO [%i]", a + 1);
    printf("\nISBN\n");
    scanf(" %[^\n]", livro[a].ISBN);
    if (*count > 0) {
        verificar(*count, &livro);

    }


    printf("\nDATA DE PUBLICAÇÂO");
    printf("\nDIA\n");
    scanf("%d", &livro[a].data_de_publicacao.dia);
    printf("\nMês\n");
    scanf("%d", &livro[a].data_de_publicacao.mes);
    printf("\nANO\n");
    scanf("%d", &livro[a].data_de_publicacao.ano);
    printf("\nTITULO\n");
    scanf(" %[^\n]", livro[a].titulo);
    printf("\n\n");
    printf("Genero do Livro");
    printf("\n1-Ficção\n2-Tecnico\n3-Romance\n4-Estudo\n");
    scanf("%d", &livro[a].tipo);
    printf("\nEditora- NOME\n");
    scanf(" %[^\n]", livro[a].editora.nome);
    printf("\nEditora- MORADA\n");
    scanf(" %[^\n]", livro[a].editora.morada);

    printf("\nNumero de autores: ");
    scanf("%i", &aux);
    while (aux <= 0 || aux > MAX_AUTORES) {
        printf("Valor invalido- Introduza novamente\n");
        printf("Valor: 0-5");
        scanf("%i", &aux);
    }
    for (int i_for = 0; i_for < aux; i_for++) {
        printf("Autor [%i]", i_for + 1);
        scanf(" %[^\n]", livro[a].autores[i_for].autores);
        printf("%s", livro[a].autores[i_for].autores);
    }
    a++;
there:
    return a;
}

void verificar(int *count, tipo_livro *livro[]) {

    for (int i = 0; i<*count; i++) {
        for (int j = 1; j<*count; j++) {
            if (livro[i]->ISBN == livro[j]->ISBN && i != j) {
                    printf("LIVRO REPETIDO");
                    return;
                }
            }
        }

    }

    char *convert_enum_to_char(tipo_genero tipo) {

        switch (tipo) {
            case 1:
                return "Ficção";
                break;
            case 2:
                return "Tecnico";
                break;
            case 3:
                return "Romance";
                break;
            case 4:
                return "Estudo";
                break;
        }
    }

    void listar_tdslivros(int *count, tipo_livro livro[]) {


        for (int i = 0; i<*count; i++) {
            printf("LIVRO [%i] da base de dados\n", i + 1);
            printf("ISBN: %s\n", livro[i].ISBN);
            printf("DATA DE PUBLICAÇÂO: %d-%d-%d\n", livro[i].data_de_publicacao.dia,
                    livro[i].data_de_publicacao.mes, livro[i].data_de_publicacao.ano);
            printf("TITULO: %s\n", livro[i].titulo);
            printf("GENERO: %s \n", convert_enum_to_char(livro[i].tipo));
            printf("EDITORA\n");
            printf("  Nome: %s\n", livro[i].editora.nome);
            printf("  Morada: %s\n", livro[i].editora.morada);
            printf("\nAUTOR(ES)");
            for (int j = 0; j < MAX_AUTORES; j++) {
                if (!livro[i].autores[j].autores) {
                    break;
                } else {
                    printf("\n AUTOR[%i]: %s", j + 1, livro[i].autores[j].autores);
                }

            }
        }
    }

    void listar_tdsautores(int *count, tipo_livro livro[]) {



        for (int i = 0; i<*count; i++) {
            for (int j = 0; j < MAX_AUTORES; j++) {


                if (livro[i].autores[j].autores) {
                    printf("\n%s", livro[i].autores[j].autores);
                }

            }
        }


    }










#endif /* BOOKLIB_H */

