/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: LAPTOP
 *
 * Created on 4 de dezembro de 2020, 13:15
 */

#include <stdio.h>
#include <stdlib.h>
#include "booklib.h"

/*
 * 
 */
int main() {
    tipo_livro livro[MAX_LIVROS];

    int menu,submenu, count = 0;

    do {
        printf("\n\nMENU");
        printf("\n1- Inserir LIVRO");
        printf("\n2- Listar LIVRO");
        printf("\n0- SAIR\n");
        scanf("%i", &menu);

        switch (menu) {
            case 1: count += inserir_livro(&count, livro);
                break;
            case 2:
                
                printf("\n\nMENU LISTAR LIVROS");
                printf("\n  1-Listar todos os livros");
                printf("\n  2-Listar todos os autores");
                printf("\n  3-Listar todas as editoras\n");
                scanf("%i", &submenu);
                switch (submenu) {
                    case 1:
                        listar_tdslivros(&count, livro);
                        break;
                    case 2:
                        //listar_tdsautores(&count, livro);
                        
                        break;
                    case 3:
                        break;

                }
                
                break;
            case 0:
                exit(1);

        }
    } while (menu != 0);
    /*
    printf("autor");
    scanf("%[^\n]",autor);
    printf("%s",autor);
     */





    return 0;
}

