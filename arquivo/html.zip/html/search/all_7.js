var searchData=
[
  ['grow_5fstructarray_5ffuncionario_71',['grow_StructArray_Funcionario',['../funcionario_8c.html#ae8e00d20e8fb77581151a1fafe417234',1,'funcionario.c']]],
  ['grow_5fstructarray_5fsalario_72',['grow_StructArray_Salario',['../salariolib_8h.html#a1ddccfa7377116fc58c03f0030cca13b',1,'grow_StructArray_Salario(SALARIO **salario):&#160;salarios.c'],['../salarios_8c.html#a1ddccfa7377116fc58c03f0030cca13b',1,'grow_StructArray_Salario(SALARIO **salario):&#160;salarios.c']]]
];
