var searchData=
[
  ['salario_163',['SALARIO',['../struct_s_a_l_a_r_i_o.html',1,'']]],
  ['salario_5fbonus_164',['salario_bonus',['../salariolib_8h.html#a2226af3ff579f61e51cb2f831d3e7028',1,'salario_bonus(FUNCIONARIO **funcionarios, SALARIO **salario, float sal_base, int cod_func):&#160;salarios.c'],['../salarios_8c.html#a2226af3ff579f61e51cb2f831d3e7028',1,'salario_bonus(FUNCIONARIO **funcionarios, SALARIO **salario, float sal_base, int cod_func):&#160;salarios.c']]],
  ['salariolib_2eh_165',['salariolib.h',['../salariolib_8h.html',1,'']]],
  ['salarios_2ec_166',['salarios.c',['../salarios_8c.html',1,'']]],
  ['solteiro_167',['SOLTEIRO',['../funclib_8h.html#ae1ebc5d0741e6f70e37256560d899558a11f74199ef8125a9bd76fa3c654d0e43',1,'funclib.h']]],
  ['soma_5fdo_5fsalario_5fde_5ffuncionario_5fem_5ffuncao_5fdo_5ftempo_168',['soma_do_salario_de_funcionario_em_funcao_do_tempo',['../salariolib_8h.html#a2ae016864b72fccebf556c586d00abf0',1,'soma_do_salario_de_funcionario_em_funcao_do_tempo(FUNCIONARIO **funcionarios, SALARIO **salario):&#160;salarios.c'],['../salarios_8c.html#a2ae016864b72fccebf556c586d00abf0',1,'soma_do_salario_de_funcionario_em_funcao_do_tempo(FUNCIONARIO **funcionarios, SALARIO **salario):&#160;salarios.c']]],
  ['ss_169',['SS',['../struct_s_s.html',1,'']]],
  ['ss_170',['ss',['../struct_s_a_l_a_r_i_o.html#a94660cae88cdd135b3f63342ab9dcfcb',1,'SALARIO']]],
  ['sub_5falimentacao_171',['sub_alimentacao',['../struct_s_a_l_a_r_i_o.html#a1002d791ae8008250e5d0533524ed5de',1,'SALARIO']]]
];
