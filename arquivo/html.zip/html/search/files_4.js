var searchData=
[
  ['salariolib_2eh_198',['salariolib.h',['../salariolib_8h.html',1,'']]],
  ['salarios_2ec_199',['salarios.c',['../salarios_8c.html',1,'']]]
];
