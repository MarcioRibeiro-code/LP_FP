var searchData=
[
  ['main_231',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['media_5fnumdias_232',['media_numdias',['../salariolib_8h.html#ae1fbda0c72d9c909cd9eccb17f521c0b',1,'media_numdias(SALARIO **salario):&#160;salarios.c'],['../salarios_8c.html#ae1fbda0c72d9c909cd9eccb17f521c0b',1,'media_numdias(SALARIO **salario):&#160;salarios.c']]],
  ['mediasalario_233',['mediaSalario',['../salariolib_8h.html#ad4d44b7ad22812bff3fc49a40c3bae0c',1,'mediaSalario(SALARIO **salario):&#160;salarios.c'],['../salarios_8c.html#ad4d44b7ad22812bff3fc49a40c3bae0c',1,'mediaSalario(SALARIO **salario):&#160;salarios.c']]],
  ['mediasalario_5fdet_5fano_234',['mediaSalario_det_ano',['../salariolib_8h.html#a10dc7a711e4f59bd658f7507752d3cef',1,'mediaSalario_det_ano(SALARIO **salario):&#160;salarios.c'],['../salarios_8c.html#a10dc7a711e4f59bd658f7507752d3cef',1,'mediaSalario_det_ano(SALARIO **salario):&#160;salarios.c']]],
  ['menu_5ffuncionarios_235',['menu_funcionarios',['../funcionario_8c.html#a29bb0fa7a16c74e5ca606d8a4fcf3e6c',1,'menu_funcionarios(FUNCIONARIO **funcionarios, FILE *fp):&#160;funcionario.c'],['../funclib_8h.html#a29bb0fa7a16c74e5ca606d8a4fcf3e6c',1,'menu_funcionarios(FUNCIONARIO **funcionarios, FILE *fp):&#160;funcionario.c']]],
  ['menu_5fsalarios_236',['menu_salarios',['../salariolib_8h.html#a3bdee150626ca7117e570a302ffbb647',1,'menu_salarios(FUNCIONARIO **funcionarios, SALARIO **salario):&#160;salarios.c'],['../salarios_8c.html#a3bdee150626ca7117e570a302ffbb647',1,'menu_salarios(FUNCIONARIO **funcionarios, SALARIO **salario):&#160;salarios.c']]]
];
