var searchData=
[
  ['base_6',['base',['../struct_s_a_l_a_r_i_o.html#a48d93a2b226cdd73ae88280f1361b2a9',1,'SALARIO']]]
];
