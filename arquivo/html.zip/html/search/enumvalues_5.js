var searchData=
[
  ['solteiro_296',['SOLTEIRO',['../funclib_8h.html#ae1ebc5d0741e6f70e37256560d899558a11f74199ef8125a9bd76fa3c654d0e43',1,'funclib.h']]]
];
