var searchData=
[
  ['idade_223',['idade',['../salariolib_8h.html#a7d77005ee0728c2d2f658457fdef3246',1,'idade(FUNCIONARIO **funcionarios, int numero):&#160;salarios.c'],['../salarios_8c.html#a7d77005ee0728c2d2f658457fdef3246',1,'idade(FUNCIONARIO **funcionarios, int numero):&#160;salarios.c']]],
  ['imprimirfuncionario_224',['imprimirFuncionario',['../funcionario_8c.html#a21836f06c0f8ee8dce14a32c413443dc',1,'imprimirFuncionario(FUNCIONARIO **funcionarios, int posicao):&#160;funcionario.c'],['../funclib_8h.html#a2e66e5796133519fd16de7fd99ce12a4',1,'imprimirFuncionario(FUNCIONARIO **funcionarios, int i):&#160;funcionario.c']]],
  ['imprimirsalario_225',['imprimirSalario',['../salariolib_8h.html#a85b1d4d9b7c4dac1fc6b494633c16417',1,'imprimirSalario(SALARIO **salario, int i):&#160;salarios.c'],['../salarios_8c.html#a361d4b26a0dba3d898fdedd409db074c',1,'imprimirSalario(SALARIO **salario, int posicao):&#160;salarios.c']]],
  ['inserir_5ffuncionario_226',['Inserir_Funcionario',['../funcionario_8c.html#a2959c2ab86abbbe0609e0d16a535b1d2',1,'Inserir_Funcionario(FUNCIONARIO **funcionarios):&#160;funcionario.c'],['../funclib_8h.html#a2959c2ab86abbbe0609e0d16a535b1d2',1,'Inserir_Funcionario(FUNCIONARIO **funcionarios):&#160;funcionario.c']]]
];
