var searchData=
[
  ['est_5fcivil_268',['est_civil',['../struct_f_u_n_c_i_o_n_a_r_i_o.html#a6f8659280b616048f8bc35cef01dad59',1,'FUNCIONARIO']]],
  ['est_5firs_269',['est_irs',['../struct_f_u_n_c_i_o_n_a_r_i_o.html#affad43ba65d0d6ba0df2b7928549e2ee',1,'FUNCIONARIO']]]
];
