var searchData=
[
  ['valor_5firs_279',['valor_irs',['../struct_s_a_l_a_r_i_o.html#ad7ec85dee3d9ddb0af3a962465348297',1,'SALARIO']]],
  ['valor_5fliquido_280',['valor_liquido',['../struct_s_a_l_a_r_i_o.html#a1d324866fc3c30f57dd3f6c6b46a57b8',1,'SALARIO']]],
  ['valor_5fss_5fempresa_281',['valor_ss_empresa',['../struct_t_i_p_o___s_s.html#a0ade01aea015b3d5ab1d4f98d062de79',1,'TIPO_SS']]],
  ['valor_5fss_5ffuncionario_282',['valor_ss_funcionario',['../struct_t_i_p_o___s_s.html#a7d6d7aa46dcde4b1ff611e9fe50afd4f',1,'TIPO_SS']]],
  ['valor_5fss_5ftotal_283',['valor_ss_total',['../struct_t_i_p_o___s_s.html#a5c3e7fc16c90f597c691d9d7ac05e44d',1,'TIPO_SS']]]
];
