var searchData=
[
  ['linhas_5fcsv_311',['LINHAS_CSV',['../funclib_8h.html#a2447319b4372b19197e53a4932534ac8',1,'funclib.h']]],
  ['linhas_5fcsv_5f1titular_312',['LINHAS_CSV_1titular',['../funclib_8h.html#a9233c901ae69e7e5696fe36658be4679',1,'funclib.h']]]
];
