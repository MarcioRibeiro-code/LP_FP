var searchData=
[
  ['eliminarfuncionario_215',['EliminarFuncionario',['../funcionario_8c.html#a15365eda2a8b03b58fdc4ebb0fcbc02f',1,'EliminarFuncionario(FUNCIONARIO **funcionarios):&#160;funcionario.c'],['../funclib_8h.html#a15365eda2a8b03b58fdc4ebb0fcbc02f',1,'EliminarFuncionario(FUNCIONARIO **funcionarios):&#160;funcionario.c']]],
  ['escreverficheiro_5fbinario_216',['EscreverFicheiro_Binario',['../funcionario_8c.html#aa43ed9a3975884326f6cc93ce7f489e7',1,'EscreverFicheiro_Binario(FUNCIONARIO **funcionarios, FILE *fp):&#160;funcionario.c'],['../funclib_8h.html#aa43ed9a3975884326f6cc93ce7f489e7',1,'EscreverFicheiro_Binario(FUNCIONARIO **funcionarios, FILE *fp):&#160;funcionario.c']]],
  ['escreverficheiro_5fbinario_5fsalario_217',['EscreverFicheiro_Binario_Salario',['../salariolib_8h.html#a066ee38160d3c0cccca34ad12d8e8485',1,'EscreverFicheiro_Binario_Salario(SALARIO **salario):&#160;salarios.c'],['../salarios_8c.html#a066ee38160d3c0cccca34ad12d8e8485',1,'EscreverFicheiro_Binario_Salario(SALARIO **salario):&#160;salarios.c']]],
  ['est_5firs_5ftostring_218',['EST_IRS_ToString',['../funcionario_8c.html#aa856779ca2d553ade7884e7b876f32ff',1,'funcionario.c']]],
  ['estadociviltostring_219',['estadoCivilToString',['../funcionario_8c.html#afae628dd71639aed183c33532560d812',1,'funcionario.c']]]
];
