var searchData=
[
  ['tamanho_172',['tamanho',['../struct_f_u_n_c_i_o_n_a_r_i_o.html#a0a06f50c808099546e057b445cc90c14',1,'FUNCIONARIO::tamanho()'],['../struct_s_a_l_a_r_i_o.html#a0a06f50c808099546e057b445cc90c14',1,'SALARIO::tamanho()']]],
  ['tamanho_5finicial_173',['TAMANHO_INICIAL',['../funclib_8h.html#a1eedfb200c0e7e8c40ff6487fac169e4',1,'funclib.h']]],
  ['tipo_5fss_174',['TIPO_SS',['../struct_t_i_p_o___s_s.html',1,'']]]
];
