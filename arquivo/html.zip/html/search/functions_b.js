var searchData=
[
  ['readcsv_246',['readcsv',['../salariolib_8h.html#a0572f6eed1578dc9669ef64a14d3857b',1,'readcsv(dict *values, int est_irs):&#160;salarios.c'],['../salarios_8c.html#a0572f6eed1578dc9669ef64a14d3857b',1,'readcsv(dict *values, int est_irs):&#160;salarios.c']]],
  ['readcsv_5fseg_5fsocial_247',['readcsv_seg_social',['../salariolib_8h.html#a302f6c1f020cda9a41f6f7932537a95b',1,'readcsv_seg_social(SS values[]):&#160;salarios.c'],['../salarios_8c.html#a302f6c1f020cda9a41f6f7932537a95b',1,'readcsv_seg_social(SS values[]):&#160;salarios.c']]]
];
