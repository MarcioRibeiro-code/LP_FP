var searchData=
[
  ['tamanho_278',['tamanho',['../struct_f_u_n_c_i_o_n_a_r_i_o.html#a0a06f50c808099546e057b445cc90c14',1,'FUNCIONARIO::tamanho()'],['../struct_s_a_l_a_r_i_o.html#a0a06f50c808099546e057b445cc90c14',1,'SALARIO::tamanho()']]]
];
