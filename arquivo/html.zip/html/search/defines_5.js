var searchData=
[
  ['tamanho_5finicial_366',['TAMANHO_INICIAL',['../funclib_8h.html#a1eedfb200c0e7e8c40ff6487fac169e4',1,'funclib.h']]]
];
