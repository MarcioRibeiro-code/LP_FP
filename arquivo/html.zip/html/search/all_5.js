var searchData=
[
  ['eliminarfuncionario_43',['EliminarFuncionario',['../funcionario_8c.html#a15365eda2a8b03b58fdc4ebb0fcbc02f',1,'EliminarFuncionario(FUNCIONARIO **funcionarios):&#160;funcionario.c'],['../funclib_8h.html#a15365eda2a8b03b58fdc4ebb0fcbc02f',1,'EliminarFuncionario(FUNCIONARIO **funcionarios):&#160;funcionario.c']]],
  ['empregado_44',['EMPREGADO',['../funclib_8h.html#acf4048424379c278f3580634aac37a06abddad61176375df57c8242ff8b3d5a3e',1,'funclib.h']]],
  ['erro_5fdata_5fde_5fsaida_45',['ERRO_DATA_DE_SAIDA',['../funclib_8h.html#aaed8bd9176291ac1339a51f42d2ef8b9',1,'funclib.h']]],
  ['erro_5ffuncionario_5fexiste_46',['ERRO_FUNCIONARIO_EXISTE',['../funclib_8h.html#a90f14e40a4c6abae18ff8794927b1c3a',1,'funclib.h']]],
  ['erro_5ffuncionario_5fnao_5fexiste_47',['ERRO_FUNCIONARIO_NAO_EXISTE',['../funclib_8h.html#af9f065cb505eef0ade89aee7b251d93a',1,'funclib.h']]],
  ['erro_5flista_5fcheia_48',['ERRO_LISTA_CHEIA',['../funclib_8h.html#a65d3b21c5bfbd8ac97abd329e5a56ead',1,'funclib.h']]],
  ['erro_5flista_5ffuncionario_5fvazia_49',['ERRO_LISTA_FUNCIONARIO_VAZIA',['../funclib_8h.html#a5b3712466fe81918338683952d3b2ca8',1,'funclib.h']]],
  ['erro_5flista_5fsalario_5fvazia_50',['ERRO_LISTA_SALARIO_VAZIA',['../funclib_8h.html#a069ce8ee552859eb570a9e5351c59c2c',1,'funclib.h']]],
  ['escreverficheiro_5fbinario_51',['EscreverFicheiro_Binario',['../funcionario_8c.html#aa43ed9a3975884326f6cc93ce7f489e7',1,'EscreverFicheiro_Binario(FUNCIONARIO **funcionarios, FILE *fp):&#160;funcionario.c'],['../funclib_8h.html#aa43ed9a3975884326f6cc93ce7f489e7',1,'EscreverFicheiro_Binario(FUNCIONARIO **funcionarios, FILE *fp):&#160;funcionario.c']]],
  ['escreverficheiro_5fbinario_5fsalario_52',['EscreverFicheiro_Binario_Salario',['../salariolib_8h.html#a066ee38160d3c0cccca34ad12d8e8485',1,'EscreverFicheiro_Binario_Salario(SALARIO **salario):&#160;salarios.c'],['../salarios_8c.html#a066ee38160d3c0cccca34ad12d8e8485',1,'EscreverFicheiro_Binario_Salario(SALARIO **salario):&#160;salarios.c']]],
  ['est_5fcivil_53',['est_civil',['../struct_f_u_n_c_i_o_n_a_r_i_o.html#a6f8659280b616048f8bc35cef01dad59',1,'FUNCIONARIO']]],
  ['est_5firs_54',['est_irs',['../struct_f_u_n_c_i_o_n_a_r_i_o.html#affad43ba65d0d6ba0df2b7928549e2ee',1,'FUNCIONARIO']]],
  ['est_5firs_5ftostring_55',['EST_IRS_ToString',['../funcionario_8c.html#aa856779ca2d553ade7884e7b876f32ff',1,'funcionario.c']]],
  ['estado_5fcivil_56',['ESTADO_CIVIL',['../funclib_8h.html#ae1ebc5d0741e6f70e37256560d899558',1,'funclib.h']]],
  ['estado_5firs_57',['ESTADO_IRS',['../funclib_8h.html#ab80ac07297723eb24420413614c7b327',1,'funclib.h']]],
  ['estadociviltostring_58',['estadoCivilToString',['../funcionario_8c.html#afae628dd71639aed183c33532560d812',1,'funcionario.c']]]
];
