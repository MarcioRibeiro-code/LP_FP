var searchData=
[
  ['administrador_1',['ADMINISTRADOR',['../funclib_8h.html#acf4048424379c278f3580634aac37a06ac62cf7b32b3f068e2dcf6856645ccfe4',1,'funclib.h']]],
  ['ano_2',['ano',['../struct_d_a_t_a.html#ac404d93cbf0169fd9e89edc17d0c5572',1,'DATA']]],
  ['antiguidade_3',['antiguidade',['../salariolib_8h.html#a8f8ceb042e16bef9c7edb7d3fc39f6c5',1,'antiguidade(FUNCIONARIO **funcionarios, int numero):&#160;salarios.c'],['../salarios_8c.html#a8f8ceb042e16bef9c7edb7d3fc39f6c5',1,'antiguidade(FUNCIONARIO **funcionarios, int numero):&#160;salarios.c']]],
  ['assuididade_4',['Assuididade',['../salariolib_8h.html#a02376b412978b1cc11c83bfe9fa7fdc0',1,'Assuididade(SALARIO **salario, int id, int tamanho):&#160;salarios.c'],['../salarios_8c.html#a02376b412978b1cc11c83bfe9fa7fdc0',1,'Assuididade(SALARIO **salario, int id, int tamanho):&#160;salarios.c']]],
  ['atualizarfuncionario_5',['AtualizarFuncionario',['../funcionario_8c.html#a05a5e47b5475e6e68206561e5b6cd8af',1,'AtualizarFuncionario(FUNCIONARIO **funcionarios):&#160;funcionario.c'],['../funclib_8h.html#a05a5e47b5475e6e68206561e5b6cd8af',1,'AtualizarFuncionario(FUNCIONARIO **funcionarios):&#160;funcionario.c']]]
];
