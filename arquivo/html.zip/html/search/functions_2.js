var searchData=
[
  ['devolve_5ftempo_214',['devolve_tempo',['../funcionario_8c.html#a82e576484fd0fc5911bcf0c7c5bd7788',1,'devolve_tempo(char opcao):&#160;funcionario.c'],['../funclib_8h.html#a82e576484fd0fc5911bcf0c7c5bd7788',1,'devolve_tempo(char opcao):&#160;funcionario.c']]]
];
