var searchData=
[
  ['administrador_288',['ADMINISTRADOR',['../funclib_8h.html#acf4048424379c278f3580634aac37a06ac62cf7b32b3f068e2dcf6856645ccfe4',1,'funclib.h']]]
];
