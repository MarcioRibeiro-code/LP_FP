var searchData=
[
  ['salario_5fbonus_248',['salario_bonus',['../salariolib_8h.html#a2226af3ff579f61e51cb2f831d3e7028',1,'salario_bonus(FUNCIONARIO **funcionarios, SALARIO **salario, float sal_base, int cod_func):&#160;salarios.c'],['../salarios_8c.html#a2226af3ff579f61e51cb2f831d3e7028',1,'salario_bonus(FUNCIONARIO **funcionarios, SALARIO **salario, float sal_base, int cod_func):&#160;salarios.c']]],
  ['soma_5fdo_5fsalario_5fde_5ffuncionario_5fem_5ffuncao_5fdo_5ftempo_249',['soma_do_salario_de_funcionario_em_funcao_do_tempo',['../salariolib_8h.html#a2ae016864b72fccebf556c586d00abf0',1,'soma_do_salario_de_funcionario_em_funcao_do_tempo(FUNCIONARIO **funcionarios, SALARIO **salario):&#160;salarios.c'],['../salarios_8c.html#a2ae016864b72fccebf556c586d00abf0',1,'soma_do_salario_de_funcionario_em_funcao_do_tempo(FUNCIONARIO **funcionarios, SALARIO **salario):&#160;salarios.c']]]
];
