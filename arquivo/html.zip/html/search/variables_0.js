var searchData=
[
  ['ano_250',['ano',['../struct_d_a_t_a.html#ac404d93cbf0169fd9e89edc17d0c5572',1,'DATA']]]
];
