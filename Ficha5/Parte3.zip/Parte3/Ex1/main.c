/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: LAPTOP
 *
 * Created on 18 de novembro de 2020, 14:20
 */

#include <stdio.h>
#include <stdlib.h>

#include <ctype.h>

#include "LIB.H"


//constantes

#define mes 12

/*
 * 
 */
int main() {


    //Variaveis globais
    int cod, op = 1, dia;
    //Salario base,subsidio de alimentação,valor iliquido,irs
    int vencb[mes], suba[mes], valoi[mes], irs[mes], ss[mes], valol[mes];
    //TOTAL
    int total_liquido, total_iliquido, total_sub_al, total_ss, total_emp_m[mes],
    total_emp_total;
    //
    char cargo;
    //

    do {

        printf("Codigo funcionario: ");
        scanf("%i", &cod);
        //99 SAIR
        if (cod == 99) {
            return (0);
        }



        //Obter Cargo Funcionario
        //Cargo S - sair
        printf("Cargo funcionario: ");
        scanf(" %c", &cargo);

        cargo = toupper(cargo);

        //verificação
        while (cargo != 'E' && cargo != 'C' && cargo != 'A' && cargo != 'S') {
            printf("Opção invalida. Introduza novamente\n");
            scanf(" %c", &cargo);
        }
        if (cargo == 'S') {
            return (0);
        } else {
            switch (cargo) {
                case'E':

                    for (int i = 0; i < mes ; i++) {

                        printf("Mes [%i]", i);
                        printf("Numero de dias: ");
                        scanf("%i", &dia);
                        do {
                            printf("Valor Invalido");
                            printf("\nNumero de dias: ");
                            scanf("%i", &dia);
                        } while (dia < 0 || dia > 30);


                        vencb[i] = salarioBase(dia);
                        suba[i] = subsidioAlimentacao(dia, cargo);
                        valoi[i] = vencb[i] + suba[i];
                        irs[i] = IRS(valoi[i]);
                        ss[i] = SS(cargo, valoi[i]);
                       valol[i] = Valol(cargo, valoi[i], irs[i]);

                        break;


                    }




            }
        }
        printf("Sair - 0   \n");
        scanf("%i", &op);
    } while (op != 0);
    //imprimir
    if (cargo == 'C' || cargo == 'E') {
        for (int i = 0; i < mes; i++) {
            total_liquido += valol[i];
            total_iliquido += valoi[i];
            total_sub_al += suba[i];
            total_ss = (valoi[i]*0.2375) * mes;
            total_emp_m[i] = valoi[i] + suba[i]+(valoi[i]*0.2375);
            total_emp_total += total_emp_m[i];
            printf("\n\nMes %i", i + 1);
            printf("\nValor Iliquido: %i", valoi[i]);
            printf("\n Subsidio de Alimentação: %i", suba[i]);
            printf("\n IRS: %i", irs[i]);
            printf("\n Segurança Social: %i", ss[i]);
            printf("\n Valor Liquido: %i", valol[i]);
            printf("\n Total empresa: %i", total_emp_m[i]);
        }

    } else {
        for (int i = 0; i < mes; i++) {
            total_liquido += valol[i];
            total_iliquido += valoi[i];
            total_sub_al += suba[i];
            total_ss = (valoi[i]*0.21) * mes;
            total_emp_m[i] = valoi[i] + suba[i]+(valoi[i]*0.21);
            total_emp_total += total_emp_m[i];
            printf("\n\nMes %i", i + 1);
            printf("\nValor Iliquido: %i", valoi[i]);
            printf("\n Subsidio de Alimentação: %i", suba[i]);
            printf("\n IRS: %i", irs[i]);
            printf("\n Segurança Social: %i", ss[i]);
            printf("\n Valor Liquido: %i", valol[i]);

            printf("\n Total empresa 1M: %i", total_emp_m[i]);
        }
        printf("\n Total 12M: %i", total_liquido);
        printf("\n\n\n\n\nTotal empresa 12 meses: %i", total_emp_total);

    }





    return 0;
}

