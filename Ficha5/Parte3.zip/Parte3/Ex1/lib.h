/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   lib.h
 * Author: LAPTOP
 *
 * Created on 18 de novembro de 2020, 14:22
 */

#ifndef LIB_H
#define LIB_H

//Valor iliquido < 1000
#define IRS_900 0.1
//Valor ilquido >=1000 ou < 2500
#define IRS_1000 0.2
//Valor iliquido >=2500 
#define IRS_2500 0.3
//Valor ARRAY MES
#define mes 12
//SS funcionario,chefe
#define ss_fc 0.11
//SS Administrador
#define ss_a 0.09

int salarioBase(int dia) {

    if (dia > 20) {
        return (dia * 40)*1.05;
    } else if (dia > 17 && dia < 20) {
        return (dia * 40)*1.02;
    } else {
        return dia * 40;
    }
}

int subsidioAlimentacao(int dia, char cargo) {
    if (cargo == 'E') {
        return dia * 5;
    } else if (cargo == 'C' && cargo == 'A') {
        return dia * 7.5;
    }
}

int IRS(int valoi) {
    if (valoi < 1000) {
        return (valoi)*IRS_900;
    } else if (valoi >= 1000 && valoi < 2500) {
        return (valoi)*IRS_1000;
    } else {
        return (valoi)*IRS_2500;
    }
}

int SS(char cargo, int valoi) {
    if (cargo == 'E' && cargo == 'C') {
        return valoi * 5;
    } else if (cargo == 'A') {
        return valoi * 7.5;
    }

}

float Valol(char cargo, int valoi[mes], int irs[mes]) {

    for (int i = 0; i < mes; i++) {
        if (cargo == 'E' && cargo == 'C') {
            return (valoi[i] -irs[i]-(valoi[i]*ss_fc));
        }else{
            return (valoi[i]-irs[i]-(valoi[i]*ss_a));
        }
    }

}




#endif /* LIB_H */

